<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE");

require_once __DIR__ . '/../src/Usuario.php';

$usuario = new Usuario();
$method = $_SERVER['REQUEST_METHOD'];
$uri = explode('/', trim($_SERVER['REQUEST_URI'], '/'));
$id = $uri[count($uri) - 1] ?? null;

switch ($method) {
    case 'GET':
        echo json_encode($usuario->listar());
        break;

    case 'POST':
        $data = json_decode(file_get_contents("php://input"));
        echo json_encode($usuario->criar($data->nome, $data->email));
        break;

    case 'PUT':
        $data = json_decode(file_get_contents("php://input"));
        $resultado = $usuario->atualizar((int)$id, $data->nome, $data->email);
        echo json_encode($resultado ?? ["erro" => "Usuário não encontrado"]);
        break;

    case 'DELETE':
        $resultado = $usuario->deletar((int)$id);
        echo json_encode(["mensagem" => $resultado ? "Usuário deletado" : "Usuário não encontrado"]);
        break;

    default:
        http_response_code(405);
        echo json_encode(["erro" => "Método não permitido"]);
}
?>
