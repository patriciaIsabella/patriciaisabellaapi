<?php
require_once __DIR__ . '/../config/database.php';

class Usuario {
    private $db;
    private $data;

    public function __construct() {
        $this->db = new Database();
        $this->data = $this->db->getData();
    }

    public function listar() {
        return $this->data;
    }

    public function criar($nome, $email) {
        $novo = [
            "id" => count($this->data) + 1,
            "nome" => $nome,
            "email" => $email
        ];
        $this->data[] = $novo;
        $this->db->saveData($this->data);
        return $novo;
    }

    public function atualizar($id, $nome, $email) {
        foreach ($this->data as &$usuario) {
            if ($usuario["id"] == $id) {
                $usuario["nome"] = $nome;
                $usuario["email"] = $email;
                $this->db->saveData($this->data);
                return $usuario;
            }
        }
        return null;
    }

    public function deletar($id) {
        foreach ($this->data as $key => $usuario) {
            if ($usuario["id"] == $id) {
                unset($this->data[$key]);
                $this->db->saveData(array_values($this->data));
                return true;
            }
        }
        return false;
    }
}
?>
